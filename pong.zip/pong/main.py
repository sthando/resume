from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
import random
import time
from scoreboard import Scoreboard

#======================================================================================================================================================================================================
# SCREEN SETTINGS
#======================================================================================================================================================================================================
screen = Screen()
WIDTH, HEIGHT = 1500, 750
screen.setup(width = WIDTH, height = HEIGHT)
screen.bgcolor("black")
screen.title("Pong")

screen.tracer(0)  
def dashed_line(fudu,length=10):
    bar_length = 10
    steps = int(length/bar_length)
    for _ in range(steps):
        tim.penup()
        tim.forward(bar_length)
        tim.pendown()
        tim.forward(bar_length)
        
mr_border = Turtle()
mr_border.pencolor("white")
mr_border.pensize(3)
mr_border.hideturtle()
mr_border.penup()
mr_border.goto(WIDTH/2*-1+40, HEIGHT/2-40)
mr_border.pendown()
mr_border.goto(WIDTH/2 - 40, HEIGHT/2-40)
mr_border.goto(WIDTH/2 - 40, HEIGHT/2*-1+40)
mr_border.goto(WIDTH/2*-1 + 40, HEIGHT/2*-1+40)
mr_border.goto(WIDTH/2*-1 + 40, HEIGHT/2 - 40)
    
 
tim = Turtle()
tim.penup()
tim.hideturtle()
tim.goto(0,HEIGHT/2)
tim.pencolor("white")
tim.pensize(3)
tim.setheading(270)
dashed_line(tim,HEIGHT/2)

#====================================================================================================================================================================================================
#PADDLES SETTINGS
#====================================================================================================================================================================================================
pad_left = Paddle(-1*WIDTH/2 + 40)
pad_right = Paddle(WIDTH/2 - 40)


screen.listen()
screen.onkeypress(pad_right.up,"Up")
screen.onkeypress(pad_right.down,"Down")
screen.onkeypress(pad_left.up,"w")
screen.onkeypress(pad_left.down,"s")

#======================================================================================================================================================================================================
#BALL SETTINGS
#======================================================================================================================================================================================================

ball = Ball()
init = [-45,45]
ball.setheading(random.uniform(init[0],init[1]))

#======================================================================================================================================================================================================
#SCOREBOARD SETTINGS
#======================================================================================================================================================================================================
scoreboard = Scoreboard()

#======================================================================================================================================================================================================
#CONTROL SECTION
#======================================================================================================================================================================================================
game_is_on = True
level=1
start_time = time.perf_counter()
while game_is_on:
    screen.update()
    #=================================================================================================================================================================================================
    #SPEED CONTROL
    #=================================================================================================================================================================================================
    current_time = time.perf_counter()
    running_time = current_time - start_time
    if running_time > 120: # 
        level+=1
        start_time = current_time
        
    #=================================================================================================================================================================================================
    #HUMAN TOUCH
    #=================================================================================================================================================================================================
    human_inefficiency = random.uniform(-1,1)
    ball.forward(level)
    scoreboard.update_scoreboard()
    # Detect collision with any of the 4 walls
    
    # UPPER WALL
    if ball.distance((ball.xcor(),HEIGHT/2-40))<15:
        ball.setheading(-1*ball.heading())
        
    # LOWER WALL
    elif ball.distance((ball.xcor(),-HEIGHT/2+40))<15:
        ball.setheading(-1*ball.heading())
    
    # LEFT PADDLE
    elif ball.distance(pad_left)<50 and ball.xcor()<=-WIDTH/2+60:
        ball.setheading(180-1*ball.heading() + human_inefficiency)
    
    # RIGHT WALL
    elif ball.distance(pad_right)<50 and ball.xcor()>=WIDTH/2-60:
        ball.setheading(180-1*ball.heading() + human_inefficiency) 
    
    elif abs(ball.xcor()) > WIDTH/2:
        game_is_on = False
    
    elif abs(ball.xcor())>WIDTH/2 - 40:
        if ball.xcor()<0:
            scoreboard.r_point()
        else:
            scoreboard.l_point()
        time.sleep(3)
        ball.goto(0,0)
        init[0] = init[0]+180
        init[1] = init[1]+180
        ball.setheading(random.uniform(init[0],init[1]))
        
    time.sleep(0.001)
# exit screen when click on it
screen.exitonclick()