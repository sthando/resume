from turtle import Turtle
class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.penup()
        self.color("white")
        self.hideturtle()
        self.score_l = 0
        self.score_r = 0
        
    def update_scoreboard(self):
        self.clear()
        self.goto(-80,330)
        self.write(self.score_l,font=("Courier",30,"normal"))
        self.goto(60,330)
        self.write(self.score_r,font=("Courier",30,"normal"))
    
    def l_point(self):
        self.score_l+=1
    
    def r_point(self):
        self.score_r+=1
        