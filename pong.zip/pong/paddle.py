from turtle import Turtle
class Paddle(Turtle):
    def __init__(self,side):
        super().__init__()
        self.fillcolor("white")
        self.shape("square")
        self.shapesize(stretch_wid = 4, stretch_len= 1, outline = 0)
        self.goto(self.xcor()+side, self.ycor())
        
    def up(self):
        self.goto(self.xcor(),self.ycor()+20)
    
    def down(self):
        self.goto(self.xcor(),self.ycor()-20)
            